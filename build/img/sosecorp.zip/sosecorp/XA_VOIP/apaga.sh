killall -9 CORE_ACC.pl
killall -9 CORE_DSC.pl
killall -9 CORE_OUT1.pl
