killall -9 CORE_ACC.pl
/opt/xien/seven/CORE_ACC.pl &

killall -9 CORE_DSC.pl
/opt/xien/seven/CORE_DSC.pl &

killall -9 CORE_OUT1.pl
/opt/xien/seven/CORE_OUT1.pl &
