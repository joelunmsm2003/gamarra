#!/usr/bin/perl

system("curl 'http://localhost/seven777/adm/admserv/cerrar.php'")
