killall -9 CORE_ACC.pl
killall -9 CORE_DSC.pl
killall -9 CORE_OUT.pl
killall -9 CORE_PRE.pl
killall -9 CORE_OUT_PRE.pl
