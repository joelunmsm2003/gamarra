#!/usr/bin/perl

do{

	 print 'CORE_PRE....';
     #system("php-cgi -q '/opt/sosecorp/pro_acd.php'");
     sleep 3;

} while(1);
